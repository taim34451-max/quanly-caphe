<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='epp.package.jee' timestamp='1772704689303'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.jee.product/target/products/epp.package.jee/win32/win32/x86_64/eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/agent/workspace/epp_master/packages/org.eclipse.epp.package.jee.product/target/products/epp.package.jee/win32/win32/x86_64/eclipse'/>
  </properties>
</profile>
